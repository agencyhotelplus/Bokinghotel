# BookingHotel — Real Hotel Catalog

Database ini berisi nama hotel nyata yang diverifikasi dari direktori resmi Marriott Bonvoy dan IHG Indonesia.

Yang sengaja TIDAK dibuat-buat:
- harga kamar
- ketersediaan kamar
- nomor WhatsApp hotel
- rating palsu
- foto hotel yang tidak memiliki lisensi

Untuk booking real-time, gunakan API/partner resmi atau arahkan pelanggan ke situs resmi hotel sampai integrasi partner tersedia.

Sumber:
- Marriott Indonesia Hotel Sitemap
- IHG Indonesia Hotel Directory
